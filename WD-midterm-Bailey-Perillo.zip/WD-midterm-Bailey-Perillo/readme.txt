Create a Website for your made up business
Requirements: 90%

Home page
  Full Layout with pictures, navigation, header section,     footer section
  
About / Contact Page 
  Contact information about the business
  Background on owners
  Form to fill out that opens an email when submitted
  
Ordering Page
  Javascript form that allows the user to build a cart of items
  when totaled adds tax and shipping fees
  Order button generates an order complete screen
  
Product Page
  Images and details on all products offered on the site
  Use HTML, CSS & JavaScript
  
Design & Accessibility - 10%
  Make sure site looks nice and is easy to read with color choices and images have alt text for screen reader to use.
  
Submission: Put all files in a folder with your name, zip the folder and upload to blackboard. Make sure the files are in the proper directory structure so that when i open the folder and click on the html file everything loads.
